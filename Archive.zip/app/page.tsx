
export default function Home() {
  return (
    <>
      <div>
        <h1>
          Hwllo next js
        </h1>
      </div>
      
    
    </>
   
  );
}
